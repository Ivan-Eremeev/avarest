// Fullpage
function fullpage(block) {
	if (block.length) {
		block.fullpage({
		
		});
	}
}
fullpage();